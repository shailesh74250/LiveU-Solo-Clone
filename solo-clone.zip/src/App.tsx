import React from 'react';

function App() {
  return (
         <h1>hello from solo clone</h1>
  );
}

export default App;
